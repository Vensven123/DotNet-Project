﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Newlogin_and_reg.Models;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Net.Mime;


namespace Newlogin_and_reg.Controllers
{
    public class HomeController : Controller
    {
        //This line use to connect to the webconfig for database connection
        public static string connectionstring = ConfigurationManager.ConnectionStrings["ConnectionDB"].ToString();

        [HttpGet]
        public ActionResult Login()
        {

            ViewBag.Message = TempData["result"];
            ViewBag.Message2 = TempData["Failed"];
            ViewBag.Message3 = TempData["Login"];
            ViewBag.Message4 = TempData["NotLogin"];
            //ViewBag.Message5 = TempData["Email"];
            ViewBag.Message6 = TempData["NotAvailableEmail"];
            ViewBag.Message7 = TempData["Email"];
            ViewBag.Message8 = TempData["EmailFailled"];


            return View();
        }

        [HttpPost]
        public ActionResult CheckLogin(LoginForm us)
        {

            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("Sp_CheckUser", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserName", us.UserName);
                //cmd.Parameters.AddWithValue("@PassWord",Common_Methods.ConvertToDecrypt( us.PassWord));
                cmd.Parameters.AddWithValue("@PassWord", us.PassWord);
                cmd.ExecuteNonQuery();
                SqlDataReader dt = cmd.ExecuteReader();
                if (dt.Read())
                {

                    // Here using cookies for UserName Display in view
                    FormsAuthentication.SetAuthCookie(us.UserName, true);
                    TempData["Login"] = Session["UserName"] = us.UserName.ToString();
                    return RedirectToAction("Login");
                }
                else
                {
                    TempData["NotLogin"] = "Not Ok";
                    return RedirectToAction("Login");
                }
            }

        }



        //__________________________________________________________RegForm___________________________________________________________________//


        [HttpGet]
        public ActionResult RegForm()
        {

            return View();
        }

        [HttpPost]
        public ActionResult RegForm(RegForm user)
        {

            using (SqlConnection con = new SqlConnection(connectionstring))
            {

                SqlCommand cmd = new SqlCommand("Sp_AddUserDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@UserName", user.UserName);
                cmd.Parameters.AddWithValue("@Email", user.Email);
               
                cmd.Parameters.AddWithValue("@PassWord",user.PassWord);
                cmd.Parameters.AddWithValue("@ConfirmPassword",user.ConfirmPassWord);
                if (user.PassWord == user.ConfirmPassWord)
                {
                    TempData["result"] = "ok";
                    cmd.ExecuteNonQuery();

                    return RedirectToAction("Login");
                }

                else
                {
                    TempData["Failed"] = "Not Ok";

                    return RedirectToAction("Login");
                }

            }

        }




        //--------------------------------------------------------------------------Forgot PassWord---------------------------------------------------//
        [HttpGet]
        public ActionResult ForgotPassWord()
        {

            return View();

        }


        public ActionResult CheckEmail(RegForm us)
        {
           
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SP_CheckEmail", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Email", us.Email);
               
                SqlDataReader dt = cmd.ExecuteReader();
                if (dt.HasRows == true)
                {
                    dt.Read();
                  
                    SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
                    client.EnableSsl = true;
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential("Enter Your Mail", "PassWord");
                    MailMessage msg = new MailMessage();
                    msg.To.Add(us.Email);
                    msg.From = new MailAddress("For Forgot PassWord<Enter Your mail Id>");
                    msg.Subject = "Your PassWord";

                   // msg.Body = db.ToString();
                    msg.Body = string.Format("ForgotPassWord Link Check it>>>>: Add Link Path here "+"<<<<<");
                    client.Send(msg);
                    TempData["Email"] = "ok";
                    RedirectToAction("Login");
                 }

                else

                {

                    TempData["NotAvailableEmail"] = "Not ok";

                    return RedirectToAction("Login");

                }

            }
           
            return RedirectToAction("Login");
        }


        //---------------------------------------------------------ResetPassWord-----------------------------------------------------//

        [HttpGet]
        public ActionResult ResetPassWord()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ResetPassWord(RegForm us)
        {
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Sp_NewPassWord", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Email", us.Email);
                cmd.Parameters.AddWithValue("@PassWord", us.PassWord);
                cmd.Parameters.AddWithValue("@ConfirmPassWord", us.ConfirmPassWord);

                if (us.PassWord == us.ConfirmPassWord)
                {

                    ViewBag.Reslut = "ok";
                    cmd.ExecuteNonQuery();
                    return RedirectToAction("Login");


                }
                else
                {

                    ViewBag.Failed = "Not ok";
                    //TempData["ResetNotDone"] = "Not ok";
                    return View();
                }

            }

        }
    }
}



   