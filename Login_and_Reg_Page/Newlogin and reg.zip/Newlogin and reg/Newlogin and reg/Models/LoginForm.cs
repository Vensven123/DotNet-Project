﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Newlogin_and_reg.Models
{
    public class LoginForm
    {
        [Required(ErrorMessage = "Oopss fil blanks")]

        public string UserName { get; set; }


        [Required(ErrorMessage = "Oopss fil blanks")]
        [MaxLength(50), MinLength(10)]
        public string PassWord { get; set; }
    }



    public class RegForm
    {
        [Required(ErrorMessage = "Please Enter Your FirstName!!!!!")]


        public string FirstName { get; set; }



        [Required(ErrorMessage = "Please Enter Your LastName!!!!!")]

        public string LastName { get; set; }


        [Required(ErrorMessage = "Please Enter Your Email!!!!!")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }


        [Required(ErrorMessage = "Please Enter Your UserName!!!!!")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Please Enter Your PassWord!!!!!")]
        [DataType(DataType.Password)]
        [MaxLength(50),MinLength(10)]
        public string PassWord { get; set; }


        [Required(ErrorMessage = "Please Enter Your ConfirmPassword!!!!!")]
        [DataType(DataType.Password)]
        [MaxLength(50), MinLength(10)]
        public string ConfirmPassWord { get; set; }





    }

    public class ForgotPassWord
    {

        [Required(ErrorMessage ="Please Enter Your Vaild Email"),EmailAddress]
        public string Email { get; set; }
    }


    public class ResetPassWord
    {

        [Required(ErrorMessage ="Enter Your Vaild Email Address"),EmailAddress]
        public string Email { get; set; }

        [Required(ErrorMessage = "Enter Your PassWord ")]
        [DataType(DataType.Password)]
        [MaxLength(50), MinLength(10)]
        public string PassWord { get; set; }

        [Required(ErrorMessage = "Enter Your Confirm PassWord")]
        [DataType(DataType.Password)]
        [MaxLength(50), MinLength(10)]
        public string ConfirmPassWord { get; set; }

    }
}